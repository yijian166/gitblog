<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
</td></tr></tbody></table>
<div>
<p align="center">欢迎使用 &copy; <a href="http://www.emlog.net" target="_blank">emlog</a></p>
<?php doAction('adm_footer');?>
</div>
</div>
</body>
</html>