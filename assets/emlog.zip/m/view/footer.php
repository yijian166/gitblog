<div id="footer">Powered By <a href="http://www.emlog.net/">emlog</a></div>
</body>
</html>